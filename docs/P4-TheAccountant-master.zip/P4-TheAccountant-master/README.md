# P4-TheAccountant
_______________________________

Bug/Problem finded :
  
  Accès direct à un EditText lors du lancement d'une activity.
  
  Appuyer longtemps sur champs input de LoginActivity -> Clipboard>Dossier des photos
  
  BackPressed dans l'activity MainActivity -> CreateAccount
_________________________________
